<?php
use App\Http\Controllers\StoreController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\AdminController;
use Illuminate\Support\Facades\Route;

Route::get('/', [StoreController::class, 'index'])->name('store');
Route::get('/health', static fn () => response()->json(['status' => 'ok']))->name('health');
Route::get('/orders/{order_number}', [OrderController::class, 'show'])->name('orders.show');
Route::post('/orders', [OrderController::class, 'store'])->middleware('throttle:10,1')->name('orders.store');
Route::post('/coupons/validate', [StoreController::class, 'validateCoupon'])->middleware('throttle:20,1')->name('coupons.validate');

Route::prefix('admin')->name('admin.')->group(function () {
    Route::get('/login', [AdminController::class, 'loginForm'])->name('login');
    Route::post('/login', [AdminController::class, 'login'])->middleware('throttle:5,1')->name('login.submit');
    Route::post('/logout', [AdminController::class, 'logout'])->name('logout');
    Route::middleware(['auth', 'can:access-admin'])->group(function () {
        Route::get('/', [AdminController::class, 'index'])->name('index');
        Route::patch('/orders/{order}', [AdminController::class, 'updateOrder'])->name('orders.update');
        Route::resource('/packages', \App\Http\Controllers\AdminPackageController::class)->except(['show']);
        Route::resource('/coupons', \App\Http\Controllers\AdminCouponController::class)->except(['show']);
    });
});
